/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class formail extends HttpServlet {


    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                
                PrintWriter p=response.getWriter();
                Random ran = new Random(); 
                int x = ran.nextInt(9999)+1000;
		String s1=request.getParameter("from");
		String s2=request.getParameter("to");
		String s3=request.getParameter("msg");
		String s4=request.getParameter("file");
		String s5=Integer.toString(x);			
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cloud","root","root");
			PreparedStatement ps1 = con.prepareStatement("select email from detail where email='"+s2+"'");
			ResultSet rst = ps1.executeQuery();
			if(rst.next())
			{
                            
                            
                        String to = s2;//change accordingly

                        // Sender's email ID needs to be mentioned
                        String from = "mani.manickam3@gmail.com";//change accordingly
                        final String username = "mani.manickam3@gmail.com";//change accordingly
                        final String password = "Manic001atlantic";//change accordingly

                        // Assuming you are sending email through relay.jangosmtp.net
                        String host = "smtp.gmail.com";

                        Properties props = new Properties();
                        props.put("mail.smtp.auth", "true");
                        props.put("mail.smtp.starttls.enable", "true");
                        props.put("mail.smtp.host", host);
                        props.put("mail.smtp.port", "587");

                        // Get the Session object.
                        Session session = Session.getInstance(props,
                        new javax.mail.Authenticator() {
                           protected PasswordAuthentication getPasswordAuthentication() {
                              return new PasswordAuthentication(username, password);
                           }
                        });

                        try {
                           // Create a default MimeMessage object.
                           Message message = new MimeMessage(session);

                           // Set From: header field of the header.
                           message.setFrom(new InternetAddress(from));

                           // Set To: header field of the header.
                           message.setRecipients(Message.RecipientType.TO,
                           InternetAddress.parse(to));

                           // Set Subject: header field
                           message.setSubject("Project reg.");

                           // Now set the actual message
                           message.setText(s3+"\nPass Key:"+x);

                           // Send message
                           Transport.send(message);

                          

                        } catch (MessagingException e) {
                              throw new RuntimeException(e);
                        }


                            
                            
                            
                        
			PreparedStatement ps = con.prepareStatement("insert into  shareu values (?,?,?,?,?)");
			ps.setString(1, s1);
			ps.setString(2, s2);
			ps.setString(3, s3);
			ps.setString(4, s4);
                        ps.setString(5, s5);
			int r = ps.executeUpdate();
			if(r>0)
			{
			request.setAttribute("datasent", "Image successfully shared");
			RequestDispatcher rd = request.getRequestDispatcher("share.jsp");
			rd.forward(request,response);
			}
			else
			{
			request.setAttribute("datasent", "Image not shared");
			RequestDispatcher rd = request.getRequestDispatcher("share.jsp");
			rd.forward(request,response);
			}
				
			}
			else
			{
				request.setAttribute("datasent", "Enter EmailID correctly");
				RequestDispatcher rd=request.getRequestDispatcher("share.jsp");
				rd.forward(request, response);
								
			}
			
		}
		catch(Exception e)
		{
			p.print(e);
		}
        
        
    }

   

}
