/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.swing.JFrame;


public class fileconv1 extends HttpServlet {

     
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        response.setContentType("text/html");
        
	PrintWriter p=response.getWriter();
     

        p.print("<br>");
        
        String filenme =request.getAttribute("nme").toString();
        
        String filename="C:\\cloud1\\web\\process\\"+filenme;
        String filename1="C:\\cloud1\\web\\process\\a"+filenme;
        
   BufferedImage  image;
   int width;
   int height;
                     
         try {
         File input = new File(filename);
         image = ImageIO.read(input);
         width = image.getWidth();
         height = image.getHeight();
         
         for(int i=0; i<height; i++){
         
            for(int j=0; j<width; j++){
            
               Color c = new Color(image.getRGB(j, i));
               int red = (int)(c.getRed() * 0.299);
               int green = (int)(c.getGreen() * 0.587);
               int blue = (int)(c.getBlue() *0.114);
               Color newColor = new Color(red+green+blue,
               
               red+green+blue,red+green+blue);
               
               image.setRGB(j,i,newColor.getRGB());
            }
         }
         
         File ouptut = new File(filename1);
         ImageIO.write(image, "jpg", ouptut);
         
      } 
         catch (Exception e) 
         {
         
         p.print(e);
         }
         
         
        p.print("<br>");
       
        
        request.setAttribute("nme1", filenme);
    
       request.getRequestDispatcher("fileconv2").forward(request, response);
        
   }
}


