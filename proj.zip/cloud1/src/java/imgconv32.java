/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Color;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;
import java.awt.image.*;

import javax.imageio.*;
import javax.imageio.stream.ImageOutputStream;

public class imgconv32 extends HttpServlet {

     
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        
	PrintWriter p=response.getWriter();
        p.print("cdfsdfs");

        p.print("<br>");
        
        String filenme =request.getAttribute("nme").toString();
        
        String filename="C:\\cloud1\\web\\process\\b"+filenme;
        String filename1="C:\\cloud1\\web\\process\\c"+filenme;  
        
        BufferedImage image;
	int width;
	int height;

            try 
            {
                    File input = new File(filename);

                    image = ImageIO.read(input);
                    width = image.getWidth();
                    height = image.getHeight();
                    int count = 0;
                    for(int i=0; i<height; i++)
                    {
                            for(int j=0; j<width; j++)
                            {
                                Color c = new Color(image.getRGB(j, i));
                                count++;

                                int red,green,blue;

                                int x = (int)(c.getRed());
                                if(x<122)
                                {
                                        red = 85;
                                }
                                else
                                {
                                        red= 0;
                                }

                                int y = (int)(c.getGreen());
                                if(y<122)
                                {
                                        green = 85;
                                }
                                else
                                {
                                        green= 0;
                                }

                                int z = (int)(c.getBlue());
                                if(z<122)
                                {
                                        blue = 85;
                                }
                                else
                                {
                                        blue = 0;
                                }

                                Color newColor = new Color(red+green+blue, red+green+blue, red+green+blue);

                                Color bcc = newColor.brighter();

                                image.setRGB(j,i,bcc.getRGB());
                            }
                    }

                File ouptut = new File(filename1);
                ImageIO.write(image, "jpg", ouptut);
            }


        catch (Exception e) 
         {
            p.print(e);
         }
        p.print("<br>");
      
      
       request.setAttribute("nme1", filenme);  
    
       request.getRequestDispatcher("imgconv23").forward(request, response);
 

  }
                
}
