import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
public class reg extends HttpServlet
{
	public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException
	{
		res.setContentType("text/html");

		String s1=req.getParameter("id");
		String s2=req.getParameter("name");
		String s3=req.getParameter("pass");
		String s4=req.getParameter("email");
		String s5=req.getParameter("phon");
	
		PrintWriter p=res.getWriter();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cloud","root","root");
			PreparedStatement ps1 = con.prepareStatement("select uid from detail where uid='"+s1+"'");
			ResultSet rst = ps1.executeQuery();
			if(rst.next())
			{
				req.setAttribute("usererr", "ID is present please change your ID");
				RequestDispatcher rd=req.getRequestDispatcher("register.jsp");
				rd.forward(req, res);
			}
			else
			{
			PreparedStatement ps = con.prepareStatement("insert into detail values(?,?,?,?,?)");
			ps.setString(1, s1);
			ps.setString(2, s2);
			ps.setString(3, s3);
			ps.setString(4, s4);
			ps.setString(5, s5);
			int r = ps.executeUpdate();
			if(r>0)
			{
			req.setAttribute("usererr", "Registration Success \n Login with ur name and Password");
			RequestDispatcher rd = req.getRequestDispatcher("index.jsp");
			rd.forward(req,res);
			}
			else
			{
			req.setAttribute("usererr", "Registration Failed");
			RequestDispatcher rd = req.getRequestDispatcher("register.jsp");
			rd.forward(req,res);
			}
			}
			
		}
		catch(Exception e)
		{
			p.print(e);
		}
	}
}	
