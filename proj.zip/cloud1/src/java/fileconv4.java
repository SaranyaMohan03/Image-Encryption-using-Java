/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Color;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;
import java.awt.image.*;

import javax.imageio.*;
import javax.imageio.stream.ImageOutputStream;

public class fileconv4 extends HttpServlet {

     
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        
	PrintWriter p=response.getWriter();
        p.print("cdfsdfs");

        p.print("<br>");
        
        String filenme =request.getAttribute("nme").toString();
        
        String filename="C:\\cloud1\\web\\process\\c"+filenme;
        String filename1="C:\\cloud1\\web\\imgs\\d"+filenme;  
        
        BufferedImage image;
	int width;
	int height;

        try 
        {
            File input = new File(filename);

            image = ImageIO.read(input);
            width = image.getWidth();
            height = image.getHeight();
            int ct = 0;
            for(int i=0; i<height; i++)
            {
                for(int j=0; j<width; j++)
                {
                    Color c = new Color(image.getRGB(j, i));
                    ct++;

                    int red,green,blue;

                    if(((ct%5)==0)||((i%5)==0))
                    {

                            Color newColor = new Color(244, 244, 244);

                       image.setRGB(j,i,newColor.getRGB());
                    }

                    else
                    {
                       Color bcc = c.darker();
                       image.setRGB(j,i,bcc.getRGB());
                    }							   
                }
            }

            File ouptut = new File(filename1);
            ImageIO.write(image, "jpg", ouptut);
        }

        catch (Exception e) 
         {
            p.print(e);
         }
        p.print("<br>");
      
      
       request.setAttribute("nme1", filenme);  
    
       request.getRequestDispatcher("/procimgs.jsp").forward(request, response);
       
   }                
}
