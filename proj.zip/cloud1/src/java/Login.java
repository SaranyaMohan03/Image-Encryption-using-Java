import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
public class Login extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String pass,name;
		name=request.getParameter("name");
		pass=request.getParameter("pass");
		HttpSession se=request.getSession();
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cloud","root","root");
			PreparedStatement ps = con.prepareStatement("select * from detail where email=? and pass=? ");
			ps.setString(1, name);
			ps.setString(2, pass);
			ResultSet rs = ps.executeQuery();
			if(rs.next())
			{	
				se.setAttribute("userName",name);
				RequestDispatcher rd = request.getRequestDispatcher("user1.jsp");
				rd.forward(request,response);

			}else
			{
				request.setAttribute("usererr", "Invalid Username and Password");
				RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
				rd.forward(request,response);
			}
		
		}
		catch(Exception e)
		{
			out.print(e);
		}
	}
}

