/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author subu
 */
public class passcheck extends HttpServlet {

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out=response.getWriter();
                  String f1=request.getParameter("f1");
           String f2=request.getParameter("f2");
           String f3=request.getParameter("f3");
           String img1=request.getParameter("img1");
           String pk=request.getParameter("pk");
           out.println(f1);
           out.println(f2);
           out.println(f3);
           out.println(img1);
           out.println(pk);
           
    
    
			
			
			{
                               	request.setAttribute("vimg",img1 );
				RequestDispatcher rd = request.getRequestDispatcher("viewimg.jsp");
				rd.forward(request,response);
					
			}
				
		
    
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
  

}
