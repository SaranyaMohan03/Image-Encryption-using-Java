/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;
import java.awt.image.*;

import javax.imageio.*;
import javax.imageio.stream.ImageOutputStream;

public class imgconv23 extends HttpServlet {

     
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
             
        
        response.setContentType("text/html");
        
	PrintWriter p=response.getWriter();
       
        
        String filenme =request.getAttribute("nme").toString();
        
        String filename="C:\\cloud1\\web\\process\\a"+filenme;
        String filename1="C:\\cloud1\\web\\process\\b"+filenme;  
        
        try{
      File input = new File(filename);
      BufferedImage image = ImageIO.read(input);

      File compressedImageFile = new File(filename1);
      OutputStream os =new FileOutputStream(compressedImageFile);

      Iterator<ImageWriter>writers =  ImageIO.getImageWritersByFormatName("jpg");
      ImageWriter writer = (ImageWriter) writers.next();

      ImageOutputStream ios = ImageIO.createImageOutputStream(os);
      writer.setOutput(ios);

      ImageWriteParam param = writer.getDefaultWriteParam();
      
      param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
      param.setCompressionQuality(10);
      writer.write(null, new IIOImage(image, null, null), param);
      
      os.close();
      ios.close();
      writer.dispose();

        }
        catch (Exception e) 
         {
         
         p.print(e);
         }
        p.print("<br>");
     
      
        request.setAttribute("nme1", filenme);    
    
       request.getRequestDispatcher("imgconv14").forward(request, response);
 

  }
                
}
